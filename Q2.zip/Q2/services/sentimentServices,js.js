const { Configuration, OpenAIApi } = require('openai');
require('dotenv').config();

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

async function analyzeSentiment(text) {
  const prompt = `Analyze the sentiment of the following news headline or tweet and reply with one word only: Positive, Negative, or Neutral.\n\n"${text}"`;

  const response = await openai.createChatCompletion({
    model: 'gpt-4',
    messages: [
      { role: 'user', content: prompt }
    ],
    temperature: 0,
  });

  const result = response.data.choices[0].message.content.trim();
  return result;
}

module.exports = { analyzeSentiment };
