const express = require('express');
const dotenv = require('dotenv');
const sentimentRoute = require('./routes/sentiment');

dotenv.config();
const app = express();

app.use(express.json());
app.use('/sentiment', sentimentRoute);

const PORT = 3001;
app.listen(PORT, () => console.log(`Sentiment server running on port ${PORT}`));
