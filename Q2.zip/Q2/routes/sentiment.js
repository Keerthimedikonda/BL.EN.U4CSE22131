const express = require('express');
const router = express.Router();
const { analyzeSentiment } = require('../services/sentimentService');

router.post('/', async (req, res) => {
    try {
        const { text } = req.body;
        if (!text) return res.status(400).json({ error: 'Text is required' });

        const sentiment = await analyzeSentiment(text);
        res.json({ sentiment });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
