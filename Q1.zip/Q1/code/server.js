const express = require('express');
const axios = require('axios');
const app = express();

const stockAPIUrl = "http://20.244.56.144/evaluation-service/stocks";

// Function to calculate Pearson's correlation coefficient
const calculateCorrelation = (data1, data2) => {
    const n = data1.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;

    for (let i = 0; i < n; i++) {
        sumX += data1[i].price;
        sumY += data2[i].price;
        sumXY += data1[i].price * data2[i].price;
        sumX2 += data1[i].price * data1[i].price;
        sumY2 += data2[i].price * data2[i].price;
    }

    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));

    return numerator / denominator;
};

// API to get average stock price for the last "m" minutes
app.get('/stocks/:ticker', async (req, res) => {
    const { ticker } = req.params;
    const { minutes } = req.query;

    try {
        const response = await axios.get(${stockAPIUrl}/${ticker}?minutes=${minutes});
        const priceHistory = response.data;

        const totalPrice = priceHistory.reduce((acc, data) => acc + data.price, 0);
        const averagePrice = totalPrice / priceHistory.length;

        res.json({
            averageStockPrice: averagePrice,
            priceHistory
        });
    } catch (error) {
        res.status(500).send("Error fetching stock data.");
    }
});

// API to get correlation between two stocks
app.get('/stockcorrelation', async (req, res) => {
    const { minutes, ticker1, ticker2 } = req.query;

    try {
        const [stock1Response, stock2Response] = await Promise.all([
            axios.get(${stockAPIUrl}/${ticker1}?minutes=${minutes}),
            axios.get(${stockAPIUrl}/${ticker2}?minutes=${minutes})
        ]);

        const priceHistory1 = stock1Response.data;
        const priceHistory2 = stock2Response.data;

        if (priceHistory1.length !== priceHistory2.length) {
            return res.status(400).send("Price histories do not align.");
        }

        const correlation = calculateCorrelation(priceHistory1, priceHistory2);

        res.json({
            correlation,
            stocks: {
                [ticker1]: { priceHistory: priceHistory1 },
                [ticker2]: { priceHistory: priceHistory2 }
            }
        });
    } catch (error) {
        res.status(500).send("Error fetching stock data.");
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(Server running on port ${PORT}));