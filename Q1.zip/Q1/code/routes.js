const express = require('express');
const router = express.Router();
const { getAverageStockPrice, getStockCorrelation } = require('../services/stockService');

// Average stock price
router.get('/:ticker', getAverageStockPrice);

// Correlation between 2 stocks
router.get('/', getStockCorrelation);

module.exports = router;
