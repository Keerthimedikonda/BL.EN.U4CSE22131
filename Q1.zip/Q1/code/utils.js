function calculateCorrelation(X, Y) {
    const n = Math.min(X.length, Y.length);
    if (n < 2) return 0;

    X = X.slice(0, n);
    Y = Y.slice(0, n);

    const avgX = X.reduce((a, b) => a + b, 0) / n;
    const avgY = Y.reduce((a, b) => a + b, 0) / n;

    let cov = 0, stdX = 0, stdY = 0;

    for (let i = 0; i < n; i++) {
        cov += (X[i] - avgX) * (Y[i] - avgY);
        stdX += (X[i] - avgX) ** 2;
        stdY += (Y[i] - avgY) ** 2;
    }

    cov /= (n - 1);
    stdX = Math.sqrt(stdX / (n - 1));
    stdY = Math.sqrt(stdY / (n - 1));

    if (stdX === 0 || stdY === 0) return 0;
    return parseFloat((cov / (stdX * stdY)).toFixed(4));
}

module.exports = { calculateCorrelation };
