const express = require('express');
const app = express();
const stockRoutes = require('./routes/stocks');

app.use(express.json());
app.use('/stocks', stockRoutes);
app.use('/stockcorrelation', stockRoutes);

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
