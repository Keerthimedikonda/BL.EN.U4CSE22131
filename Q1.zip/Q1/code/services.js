const axios = require('axios');
const { calculateCorrelation } = require('../utils/correlation');

const AUTH_TOKEN = 'YOUR_ACCESS_TOKEN_HERE';  // Replace after auth
const BASE_URL = 'http://20.244.56.144/evaluation-service';

const headers = {
    Authorization: `Bearer ${AUTH_TOKEN}`,
};

// Get average stock price
const getAverageStockPrice = async (req, res) => {
    const { ticker } = req.params;
    const minutes = parseInt(req.query.minutes);

    try {
        const resp = await axios.get(`${BASE_URL}/stocks/${ticker}/price`, { headers });
        const now = new Date();
        const priceHistory = resp.data.filter(p => (now - new Date(p.lastUpdatedAt)) / 60000 <= minutes);
        const avgPrice = priceHistory.reduce((sum, p) => sum + p.price, 0) / priceHistory.length;

        res.json({
            averageStockPrice: avgPrice,
            priceHistory,
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Get correlation
const getStockCorrelation = async (req, res) => {
    const { minutes, ticker: tickers } = req.query;
    if (!Array.isArray(tickers) || tickers.length !== 2) {
        return res.status(400).json({ error: 'Provide exactly 2 tickers.' });
    }

    try {
        const data = {};
        for (let t of tickers) {
            const resp = await axios.get(`${BASE_URL}/stocks/${t}/price`, { headers });
            const now = new Date();
            const filtered = resp.data.filter(p => (now - new Date(p.lastUpdatedAt)) / 60000 <= minutes);
            data[t] = {
                priceHistory: filtered,
                averagePrice: filtered.reduce((s, p) => s + p.price, 0) / filtered.length,
            };
        }

        const correlation = calculateCorrelation(
            data[tickers[0]].priceHistory.map(p => p.price),
            data[tickers[1]].priceHistory.map(p => p.price)
        );

        res.json({
            correlation,
            stocks: data,
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

module.exports = { getAverageStockPrice, getStockCorrelation };
